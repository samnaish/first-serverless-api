'use strict';

module.exports.helloWorld = async () => {
  const rawDateString = new Date();
  const neatDate = rawDateString.toLocaleDateString();
  const time = rawDateString.toLocaleTimeString();
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Hello World, I have done it!',
        date: neatDate,
        time: time
      }
    )
  };
};

module.exports.getParams = async (query) => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: query.params
      }
    )
  };
};

