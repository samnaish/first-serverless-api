# Hello World Using Serverless-offline

A hello world rest API that returns a meassage of (you guessed... "hello World").the application only really has on dependency, link down below;

[Vist website](https://www.npmjs.com/package/serverless-offline)

### OR, have the install command.

```
npm i serverless-offline
```
